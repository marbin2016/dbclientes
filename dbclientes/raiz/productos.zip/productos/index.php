<!DOCTYPE html>
<html lang="sp">
<head>
    <meta charset="utf-8">

    <link   href="../css/bootstrap.min.css" rel="stylesheet">
    <script src="../js/bootstrap.min.js"></script>
    
</head>

<body>
    <div class="container">
    		<div class="mmenu" align="center">
			<table width="750" >
		<tr>
		<td><H4>CONTROL DE PRODUCTOS</H4></td>
		 	<td><a href="../menu/index.php"  class="btn">Salir</a></td>	
		
		</tr>
	</table>
	<a href="create.php" alt="Nuevo Registro..." class="btn btn-info"> Nuevo</a> 
	<a href="query.php" alt="Consultar Registros..." class="btn btn-info">Consultar</a> 
	<hr>	
 

 </div>
			<div class="row">
				 
    	    </div>
    </div> <!-- /container -->
  </body>
</html>
